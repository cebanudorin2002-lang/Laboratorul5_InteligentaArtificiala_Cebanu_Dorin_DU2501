package com.galab.ui;

import com.galab.engine.GeneticAlgorithmEngine;
import com.galab.model.ExperimentResult;
import com.galab.model.GenerationStats;
import com.galab.model.Individual;
import com.galab.util.GaConstants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Главное окно лабораторной работы:
 * Генетический алгоритм оптимизации функции одной переменной.
 * Целевая функция: f(x) = sin²(4πx) + 0.3x, x ∈ [0, 1]
 * Длина хромосомы: L = 4 (фиксирована)
 */
public final class GeneticAlgorithmLabApp extends JFrame {

    // Элементы управления параметрами
    private JSpinner spinnerN;
    private JTextField fieldL;
    private JTextField fieldPc;
    private JTextField fieldPm;
    private JSpinner spinnerG;
    private JTextField fieldSeed;
    private JCheckBox checkUseSeed;

    // Компоненты вывода
    private JTextArea logTextArea;
    private DefaultTableModel evolutionTableModel;
    private DefaultTableModel statsTableModel;
    private DefaultTableModel experimentsComparisonModel;
    private FitnessChartPanel chartPanel;
    private JLabel summaryLabel;

    public GeneticAlgorithmLabApp() {
        setTitle("Лабораторная работа: Генетический алгоритм — max f(x) = sin²(4πx) + 0.3x");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1220, 820);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 1. Верхняя панель настройки параметров
        JPanel controlPanel = new JPanel(new GridBagLayout());
        controlPanel.setBorder(new TitledBorder("Параметры генетического алгоритма и управление"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        spinnerN = new JSpinner(new SpinnerNumberModel(4, 2, 20, 1));
        fieldL = new JTextField("4", 4);
        fieldL.setEditable(false);
        fieldL.setToolTipText("Длина хромосомы L = 4 фиксирована по условию");
        fieldPc = new JTextField("0.8", 6);
        fieldPm = new JTextField("0.05", 6);
        spinnerG = new JSpinner(new SpinnerNumberModel(30, 30, 500, 5));
        fieldSeed = new JTextField("42", 6);
        checkUseSeed = new JCheckBox("Фикс. Seed:", true);

        int col = 0;
        addControl(controlPanel, gbc, col++, "Размер популяции N (2..20):", spinnerN);
        addControl(controlPanel, gbc, col++, "Длина хромосомы L:", fieldL);
        addControl(controlPanel, gbc, col++, "Вероятность кроссовера pc (0..1):", fieldPc);
        addControl(controlPanel, gbc, col++, "Вероятность мутации pm (0..1):", fieldPm);
        addControl(controlPanel, gbc, col++, "Поколений G (>=30):", spinnerG);

        gbc.gridx = col++;
        gbc.gridy = 0;
        controlPanel.add(checkUseSeed, gbc);
        gbc.gridx = col++;
        controlPanel.add(fieldSeed, gbc);

        // Кнопки запуска
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        JButton btnRunSingle = new JButton("Запустить (текущие параметры)");
        JButton btnRunThreeExp = new JButton("Провести 3 обязательных эксперимента (Раздел 7)");
        buttonPanel.add(btnRunSingle);
        buttonPanel.add(btnRunThreeExp);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = col;
        controlPanel.add(buttonPanel, gbc);

        mainPanel.add(controlPanel, BorderLayout.NORTH);

        // 2. Центральная панель с вкладками
        JTabbedPane tabbedPane = new JTabbedPane();

        // Вкладка 1: Подробные логи
        logTextArea = new JTextArea();
        logTextArea.setEditable(false);
        logTextArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        JScrollPane logScroll = new JScrollPane(logTextArea);
        tabbedPane.addTab("1. Подробные логи (Раздел 8)", logScroll);

        // Вкладка 2: Таблица эволюции популяции
        String[] evoCols = {"Поколение", "Номер особи", "Хромосома", "Десятичное значение (b)", "x", "f(x)"};
        evolutionTableModel = new DefaultTableModel(evoCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable evoTable = new JTable(evolutionTableModel);
        tabbedPane.addTab("2. Таблица эволюции (Раздел 9)", new JScrollPane(evoTable));

        // Вкладка 3: Таблица статистики поколений
        String[] statsCols = {"Поколение", "Минимальный fitness", "Средний fitness", "Максимальный fitness",
                "Лучшая хромосома", "Лучший x"};
        statsTableModel = new DefaultTableModel(statsCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable statsTable = new JTable(statsTableModel);
        tabbedPane.addTab("3. Статистика поколений (Раздел 9)", new JScrollPane(statsTable));

        // Вкладка 4: График
        chartPanel = new FitnessChartPanel();
        tabbedPane.addTab("4. График max fitness по поколениям", chartPanel);

        // Вкладка 5: Сводная таблица экспериментов
        String[] expCols = {
                "Эксперимент", "N", "L", "pc", "pm", "G",
                "Лучшая хромосома", "Десятичное b*", "Итоговый x*", "Итоговый f(x*)",
                "Поколение нахождения opt", "Средний fitness (посл. пок.)"
        };
        experimentsComparisonModel = new DefaultTableModel(expCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable expTable = new JTable(experimentsComparisonModel);
        tabbedPane.addTab("5. Сравнение экспериментов (Раздел 7)", new JScrollPane(expTable));

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // 3. Нижняя панель с итоговым результатом
        summaryLabel = new JLabel(
                "Готово к запуску. Целевая функция: f(x) = sin²(4πx) + 0.3x, " +
                        "глобальный максимум на 4 битах: b=13 (1101), x*=0.8667, f(x*)=1.2491");
        summaryLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        summaryLabel.setBorder(new EmptyBorder(6, 6, 6, 6));
        mainPanel.add(summaryLabel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Обработчики событий
        btnRunSingle.addActionListener(e -> runSingleFromUI());
        btnRunThreeExp.addActionListener(e -> runThreeMandatoryExperiments());

        // Автоматический запуск серии из 3 экспериментов при старте
        SwingUtilities.invokeLater(this::runThreeMandatoryExperiments);
    }

    private void addControl(JPanel panel, GridBagConstraints gbc, int col, String labelText, JComponent comp) {
        gbc.gridx = col * 2;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        panel.add(new JLabel(labelText), gbc);
        gbc.gridx = col * 2 + 1;
        panel.add(comp, gbc);
    }

    /**
     * Считывание параметров и запуск одиночного эксперимента.
     */
    private void runSingleFromUI() {
        try {
            int n = (Integer) spinnerN.getValue();
            int g = (Integer) spinnerG.getValue();
            double pc = Double.parseDouble(fieldPc.getText().trim().replace(',', '.'));
            double pm = Double.parseDouble(fieldPm.getText().trim().replace(',', '.'));

            if (pc < 0.0 || pc > 1.0) {
                throw new IllegalArgumentException("Вероятность кроссовера pc должна быть в диапазоне [0, 1].");
            }
            if (pm < 0.0 || pm > 1.0) {
                throw new IllegalArgumentException("Вероятность мутации pm должна быть в диапазоне [0, 1].");
            }
            if (n < 2 || n > 20) {
                throw new IllegalArgumentException("Размер популяции N должен быть от 2 до 20.");
            }
            if (g < 30) {
                throw new IllegalArgumentException("Количество поколений G должно быть не менее 30.");
            }

            Long seed = null;
            if (checkUseSeed.isSelected()) {
                seed = Long.parseLong(fieldSeed.getText().trim());
            }

            GeneticAlgorithmEngine engine = new GeneticAlgorithmEngine(n, pc, pm, g, seed);
            ExperimentResult result = engine.run("Пользовательский запуск");
            displaySingleResult(result);

            List<ExperimentResult> singleList = new ArrayList<>();
            singleList.add(result);
            chartPanel.setExperiments(singleList);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Ошибка формата числа: проверьте поля pc, pm и Seed.",
                    "Ошибка ввода", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(),
                    "Некорректные параметры", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Запуск трёх обязательных экспериментов из раздела 7 задания.
     */
    private void runThreeMandatoryExperiments() {
        double[][] configs = {
                {4, 0.80, 0.05, 30}, // Эксперимент 1: стандартные сбалансированные параметры
                {4, 0.40, 0.01, 30}, // Эксперимент 2: низкие вероятности кроссовера и мутации
                {4, 0.90, 0.15, 30}  // Эксперимент 3: высокие вероятности кроссовера и мутации
        };

        Long baseSeed = null;
        if (checkUseSeed.isSelected()) {
            try {
                baseSeed = Long.parseLong(fieldSeed.getText().trim());
            } catch (NumberFormatException ignored) {
                baseSeed = 42L;
            }
        }

        List<ExperimentResult> results = new ArrayList<>();
        StringBuilder combinedLogs = new StringBuilder();
        experimentsComparisonModel.setRowCount(0);

        for (int i = 0; i < configs.length; i++) {
            int n = (int) configs[i][0];
            double pc = configs[i][1];
            double pm = configs[i][2];
            int g = (int) configs[i][3];
            Long seed = (baseSeed != null) ? (baseSeed + i * 100L) : null;
            String expName = "Эксперимент " + (i + 1);

            GeneticAlgorithmEngine engine = new GeneticAlgorithmEngine(n, pc, pm, g, seed);
            ExperimentResult res = engine.run(expName);
            results.add(res);

            combinedLogs.append("================================================================================\n");
            combinedLogs.append(String.format(Locale.US,
                    "%s (N=%d, L=%d, pc=%.2f, pm=%.2f, G=%d)\n",
                    expName.toUpperCase(), n, GaConstants.CHROMOSOME_LENGTH, pc, pm, g));
            combinedLogs.append("================================================================================\n\n");
            combinedLogs.append(res.getLogText()).append("\n\n");

            GenerationStats lastGen = res.getGenerations().get(res.getGenerations().size() - 1);
            experimentsComparisonModel.addRow(new Object[]{
                    expName,
                    n,
                    GaConstants.CHROMOSOME_LENGTH,
                    String.format(Locale.US, "%.2f", pc),
                    String.format(Locale.US, "%.2f", pm),
                    g,
                    res.getBestOverall().getChromosome(),
                    res.getBestOverall().getDecimalValue(),
                    String.format(Locale.US, "%.4f", res.getBestOverall().getX()),
                    String.format(Locale.US, "%.4f", res.getBestOverall().getFitness()),
                    res.getFirstGenerationFoundBest(),
                    String.format(Locale.US, "%.4f", lastGen.getAvgFitness())
            });
        }

        // Отображаем таблицы для 1-го эксперимента, в логах и на графике — все 3
        displayTablesForResult(results.get(0));
        logTextArea.setText(combinedLogs.toString());
        logTextArea.setCaretPosition(0);
        chartPanel.setExperiments(results);

        ExperimentResult r1 = results.get(0);
        summaryLabel.setText(String.format(Locale.US,
                "Серия из 3 экспериментов завершена! Эксп. 1: лучшая хромосома = %s (b=%d), x* = %.4f, f(x*) = %.4f",
                r1.getBestOverall().getChromosome(), r1.getBestOverall().getDecimalValue(),
                r1.getBestOverall().getX(), r1.getBestOverall().getFitness()));
    }

    private void displaySingleResult(ExperimentResult result) {
        logTextArea.setText(result.getLogText());
        logTextArea.setCaretPosition(0);
        displayTablesForResult(result);

        experimentsComparisonModel.setRowCount(0);
        GenerationStats lastGen = result.getGenerations().get(result.getGenerations().size() - 1);
        experimentsComparisonModel.addRow(new Object[]{
                result.getExperimentName(),
                result.getN(),
                GaConstants.CHROMOSOME_LENGTH,
                String.format(Locale.US, "%.2f", result.getPc()),
                String.format(Locale.US, "%.2f", result.getPm()),
                result.getG(),
                result.getBestOverall().getChromosome(),
                result.getBestOverall().getDecimalValue(),
                String.format(Locale.US, "%.4f", result.getBestOverall().getX()),
                String.format(Locale.US, "%.4f", result.getBestOverall().getFitness()),
                result.getFirstGenerationFoundBest(),
                String.format(Locale.US, "%.4f", lastGen.getAvgFitness())
        });

        summaryLabel.setText(String.format(Locale.US,
                "Итог (%s): Лучшая хромосома = %s (десятичное b = %d) | x* = %.4f | f(x*) = %.4f (найдено на поколении %d)",
                result.getExperimentName(), result.getBestOverall().getChromosome(),
                result.getBestOverall().getDecimalValue(),
                result.getBestOverall().getX(), result.getBestOverall().getFitness(),
                result.getFirstGenerationFoundBest()));
    }

    private void displayTablesForResult(ExperimentResult result) {
        evolutionTableModel.setRowCount(0);
        statsTableModel.setRowCount(0);

        for (GenerationStats gen : result.getGenerations()) {
            for (int i = 0; i < gen.getPopulation().size(); i++) {
                Individual ind = gen.getPopulation().get(i);
                evolutionTableModel.addRow(new Object[]{
                        gen.getGenerationNumber(),
                        i + 1,
                        ind.getChromosome(),
                        ind.getDecimalValue(),
                        String.format(Locale.US, "%.4f", ind.getX()),
                        String.format(Locale.US, "%.4f", ind.getFitness())
                });
            }
            statsTableModel.addRow(new Object[]{
                    gen.getGenerationNumber(),
                    String.format(Locale.US, "%.4f", gen.getMinFitness()),
                    String.format(Locale.US, "%.4f", gen.getAvgFitness()),
                    String.format(Locale.US, "%.4f", gen.getMaxFitness()),
                    gen.getBestInGeneration().getChromosome(),
                    String.format(Locale.US, "%.4f", gen.getBestInGeneration().getX())
            });
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        SwingUtilities.invokeLater(() -> new GeneticAlgorithmLabApp().setVisible(true));
    }
}
