package com.galab.ui;

import com.galab.model.ExperimentResult;
import com.galab.model.FitnessFunction;
import com.galab.model.GenerationStats;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Панель отрисовки графика изменения максимального fitness по поколениям.
 */
public final class FitnessChartPanel extends JPanel {

    private List<ExperimentResult> experiments = new ArrayList<>();

    private static final Color[] SERIES_COLORS = {
            new Color(30, 100, 220),
            new Color(220, 60, 40),
            new Color(40, 160, 70)
    };

    public FitnessChartPanel() {
        setBackground(Color.WHITE);
    }

    public void setExperiments(List<ExperimentResult> experiments) {
        this.experiments = experiments != null ? experiments : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (experiments == null || experiments.isEmpty()) {
            return;
        }

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        int padLeft = 70;
        int padRight = 40;
        int padTop = 50;
        int padBottom = 60;

        int plotW = width - padLeft - padRight;
        int plotH = height - padTop - padBottom;
        if (plotW <= 50 || plotH <= 50) {
            return;
        }

        int maxGen = 1;
        for (ExperimentResult exp : experiments) {
            if (exp.getG() > maxGen) {
                maxGen = exp.getG();
            }
        }

        double minY = 0.0;
        double maxY = 1.35; // Теоретический максимум ~1.2491

        // Сетка и подписи оси Y
        g2.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int ySteps = 5;
        for (int i = 0; i <= ySteps; i++) {
            double val = minY + (maxY - minY) * i / ySteps;
            int y = padTop + plotH - (int) ((val - minY) / (maxY - minY) * plotH);
            g2.setColor(new Color(230, 230, 230));
            g2.drawLine(padLeft, y, padLeft + plotW, y);
            g2.setColor(Color.DARK_GRAY);
            String label = String.format(Locale.US, "%.2f", val);
            g2.drawString(label, padLeft - 45, y + 5);
        }

        // Линия глобального оптимума на 4 битах
        int yOpt = padTop + plotH - (int) ((FitnessFunction.GLOBAL_OPTIMUM_4BIT - minY) / (maxY - minY) * plotH);
        g2.setColor(new Color(140, 140, 140));
        Stroke oldStroke = g2.getStroke();
        g2.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{6, 6}, 0));
        g2.drawLine(padLeft, yOpt, padLeft + plotW, yOpt);
        g2.setStroke(oldStroke);
        g2.drawString("Глобальный оптимум 4 бит: f(13/15) = 1.2491", padLeft + 10, yOpt - 6);

        // Сетка и подписи оси X
        int xStep = Math.max(1, maxGen / 10);
        for (int gen = 1; gen <= maxGen; gen += xStep) {
            int x = padLeft + (int) ((double) (gen - 1) / Math.max(1, maxGen - 1) * plotW);
            g2.setColor(new Color(235, 235, 235));
            g2.drawLine(x, padTop, x, padTop + plotH);
            g2.setColor(Color.DARK_GRAY);
            g2.drawString(String.valueOf(gen), x - 6, padTop + plotH + 20);
        }

        // Рамка графика
        g2.setColor(Color.BLACK);
        g2.drawRect(padLeft, padTop, plotW, plotH);

        // Заголовки осей
        g2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        g2.drawString("Динамика изменения максимального fitness по поколениям", padLeft, 25);
        g2.drawString("Номер поколения (G)", padLeft + plotW / 2 - 70, height - 15);

        // Отрисовка кривых
        g2.setStroke(new BasicStroke(2.2f));
        for (int s = 0; s < experiments.size(); s++) {
            ExperimentResult exp = experiments.get(s);
            Color color = SERIES_COLORS[s % SERIES_COLORS.length];
            g2.setColor(color);

            List<GenerationStats> gens = exp.getGenerations();
            for (int i = 0; i < gens.size(); i++) {
                GenerationStats st = gens.get(i);
                double x1 = padLeft + ((double) i / Math.max(1, maxGen - 1)) * plotW;
                double y1 = padTop + plotH - ((st.getMaxFitness() - minY) / (maxY - minY)) * plotH;

                if (i > 0) {
                    GenerationStats prev = gens.get(i - 1);
                    double x0 = padLeft + ((double) (i - 1) / Math.max(1, maxGen - 1)) * plotW;
                    double y0 = padTop + plotH - ((prev.getMaxFitness() - minY) / (maxY - minY)) * plotH;
                    g2.draw(new Line2D.Double(x0, y0, x1, y1));
                }
                g2.fill(new Ellipse2D.Double(x1 - 3.5, y1 - 3.5, 7, 7));
            }

            // Легенда
            int legX = padLeft + 250 * s;
            int legY = 42;
            g2.fillRect(legX, legY - 10, 14, 10);
            g2.setColor(Color.BLACK);
            g2.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            g2.drawString(String.format(Locale.US, "%s (pc=%.2f, pm=%.2f)",
                    exp.getExperimentName(), exp.getPc(), exp.getPm()), legX + 20, legY);
        }
    }
}
