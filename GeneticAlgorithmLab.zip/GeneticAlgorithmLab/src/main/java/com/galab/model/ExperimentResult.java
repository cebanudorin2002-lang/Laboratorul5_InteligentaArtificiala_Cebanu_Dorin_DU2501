package com.galab.model;

import java.util.Collections;
import java.util.List;

/**
 * Итоговый результат одного эксперимента генетического алгоритма.
 */
public final class ExperimentResult {

    private final String experimentName;
    private final int n;
    private final double pc;
    private final double pm;
    private final int g;
    private final List<GenerationStats> generations;
    private final Individual bestOverall;
    private final int firstGenerationFoundBest;
    private final String logText;

    public ExperimentResult(String experimentName,
                            int n,
                            double pc,
                            double pm,
                            int g,
                            List<GenerationStats> generations,
                            Individual bestOverall,
                            int firstGenerationFoundBest,
                            String logText) {
        this.experimentName = experimentName;
        this.n = n;
        this.pc = pc;
        this.pm = pm;
        this.g = g;
        this.generations = Collections.unmodifiableList(generations);
        this.bestOverall = bestOverall;
        this.firstGenerationFoundBest = firstGenerationFoundBest;
        this.logText = logText;
    }

    public String getExperimentName() {
        return experimentName;
    }

    public int getN() {
        return n;
    }

    public double getPc() {
        return pc;
    }

    public double getPm() {
        return pm;
    }

    public int getG() {
        return g;
    }

    public List<GenerationStats> getGenerations() {
        return generations;
    }

    public Individual getBestOverall() {
        return bestOverall;
    }

    public int getFirstGenerationFoundBest() {
        return firstGenerationFoundBest;
    }

    public String getLogText() {
        return logText;
    }
}
