package com.galab.model;

import com.galab.util.GaConstants;

/**
 * Особь (хромосома) генетического алгоритма.
 * Неизменяемый объект: хромосома, десятичное значение, x и fitness вычисляются при создании.
 */
public final class Individual {

    private final String chromosome;
    private final int decimalValue;
    private final double x;
    private final double fitness;

    public Individual(String chromosome) {
        if (chromosome == null || chromosome.length() != GaConstants.CHROMOSOME_LENGTH) {
            throw new IllegalArgumentException(
                    "Хромосома должна быть длиной " + GaConstants.CHROMOSOME_LENGTH + " бит");
        }
        this.chromosome = chromosome;
        this.decimalValue = Integer.parseInt(chromosome, 2);
        // Формула декодирования: x = b / (2^L - 1)
        this.x = (double) this.decimalValue / GaConstants.MAX_DECIMAL_VALUE;
        this.fitness = FitnessFunction.evaluate(this.x);
    }

    public String getChromosome() {
        return chromosome;
    }

    public int getDecimalValue() {
        return decimalValue;
    }

    public double getX() {
        return x;
    }

    public double getFitness() {
        return fitness;
    }

    @Override
    public String toString() {
        return String.format("Individual{chr=%s, b=%d, x=%.4f, f=%.4f}",
                chromosome, decimalValue, x, fitness);
    }
}
