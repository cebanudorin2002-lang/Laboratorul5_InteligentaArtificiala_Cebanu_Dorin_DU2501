package com.galab.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Статистика одного поколения: популяция, min/avg/max fitness и лучшая особь.
 */
public final class GenerationStats {

    private final int generationNumber;
    private final List<Individual> population;
    private final double minFitness;
    private final double maxFitness;
    private final double avgFitness;
    private final Individual bestInGeneration;

    public GenerationStats(int generationNumber, List<Individual> population) {
        if (population == null || population.isEmpty()) {
            throw new IllegalArgumentException("Популяция не может быть пустой");
        }
        this.generationNumber = generationNumber;
        this.population = Collections.unmodifiableList(new ArrayList<>(population));

        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        double sum = 0.0;
        Individual best = population.get(0);

        for (Individual ind : population) {
            double f = ind.getFitness();
            if (f < min) {
                min = f;
            }
            if (f > max) {
                max = f;
                best = ind;
            }
            sum += f;
        }

        this.minFitness = min;
        this.maxFitness = max;
        this.avgFitness = sum / population.size();
        this.bestInGeneration = best;
    }

    public int getGenerationNumber() {
        return generationNumber;
    }

    public List<Individual> getPopulation() {
        return population;
    }

    public double getMinFitness() {
        return minFitness;
    }

    public double getMaxFitness() {
        return maxFitness;
    }

    public double getAvgFitness() {
        return avgFitness;
    }

    public Individual getBestInGeneration() {
        return bestInGeneration;
    }
}
