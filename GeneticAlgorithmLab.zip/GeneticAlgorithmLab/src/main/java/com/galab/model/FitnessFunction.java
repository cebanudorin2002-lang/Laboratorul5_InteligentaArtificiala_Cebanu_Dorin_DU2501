package com.galab.model;

/**
 * Целевая функция варианта лабораторной работы.
 * f(x) = sin²(4πx) + 0.3x, x ∈ [0, 1]
 */
public final class FitnessFunction {

    private FitnessFunction() {
        // utility class
    }

    /**
     * Вычисляет значение целевой функции в точке x.
     *
     * @param x аргумент в диапазоне [0, 1]
     * @return f(x)
     */
    public static double evaluate(double x) {
        double sinVal = Math.sin(4.0 * Math.PI * x);
        return (sinVal * sinVal) + 0.3 * x;
    }

    /**
     * Теоретический глобальный максимум на 4-битной сетке (b = 13, x = 13/15).
     */
    public static final double GLOBAL_OPTIMUM_4BIT = 1.2491;
}
