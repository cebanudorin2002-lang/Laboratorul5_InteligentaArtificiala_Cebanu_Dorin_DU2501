package com.galab.engine;

import java.util.Random;

/**
 * Интерфейс оператора мутации.
 */
public interface MutationOperator {

    /**
     * Результат мутации одной хромосомы (с описанием изменений для лога).
     */
    final class MutationResult {
        public final String mutatedChromosome;
        public final String logDetails; // пустая строка, если мутаций не было

        public MutationResult(String mutatedChromosome, String logDetails) {
            this.mutatedChromosome = mutatedChromosome;
            this.logDetails = logDetails;
        }
    }

    /**
     * Применяет побитовую мутацию к хромосоме.
     *
     * @param chromosome исходная хромосома
     * @param individualIndex номер особи (1-based) для логирования
     * @param pm         вероятность мутации одного бита
     * @param random     генератор случайных чисел
     * @return результат мутации
     */
    MutationResult mutate(String chromosome, int individualIndex, double pm, Random random);
}
