package com.galab.engine;

import com.galab.model.Individual;

import java.util.List;
import java.util.Random;

/**
 * Пропорциональная селекция (метод колеса рулетки).
 * Добавляется малая константа 1e-6, чтобы особь с fitness ≈ 0 имела ненулевой шанс.
 */
public final class RouletteWheelSelection implements SelectionOperator {

    private static final double EPSILON = 1e-6;

    @Override
    public int select(List<Individual> population, Random random) {
        double totalFitness = 0.0;
        for (Individual ind : population) {
            totalFitness += (ind.getFitness() + EPSILON);
        }

        double slice = random.nextDouble() * totalFitness;
        double cumulative = 0.0;

        for (int i = 0; i < population.size(); i++) {
            cumulative += (population.get(i).getFitness() + EPSILON);
            if (cumulative >= slice) {
                return i;
            }
        }
        return population.size() - 1;
    }
}
