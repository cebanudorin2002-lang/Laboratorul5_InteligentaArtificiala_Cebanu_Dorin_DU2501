package com.galab.engine;

import com.galab.model.Individual;

import java.util.List;
import java.util.Random;

/**
 * Интерфейс оператора селекции.
 */
public interface SelectionOperator {

    /**
     * Выбирает индекс особи из популяции.
     *
     * @param population текущая популяция
     * @param random     генератор случайных чисел
     * @return индекс выбранной особи
     */
    int select(List<Individual> population, Random random);
}
