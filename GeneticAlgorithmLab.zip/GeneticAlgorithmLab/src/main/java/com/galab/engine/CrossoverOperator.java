package com.galab.engine;

import java.util.Random;

/**
 * Интерфейс оператора кроссовера.
 * Возвращает пару потомков (или копии родителей, если кроссовер не выполнен).
 */
public interface CrossoverOperator {

    /**
     * Результат операции кроссовера.
     */
    final class CrossoverResult {
        public final String child1;
        public final String child2;
        public final boolean performed;
        public final int cutPoint; // -1, если кроссовер не выполнен
        public final double randomValue;

        public CrossoverResult(String child1, String child2, boolean performed, int cutPoint, double randomValue) {
            this.child1 = child1;
            this.child2 = child2;
            this.performed = performed;
            this.cutPoint = cutPoint;
            this.randomValue = randomValue;
        }
    }

    /**
     * Выполняет кроссовер двух родительских хромосом.
     *
     * @param parent1 первая родительская хромосома
     * @param parent2 вторая родительская хромосома
     * @param pc      вероятность кроссовера
     * @param random  генератор случайных чисел
     * @return результат с потомками и метаданными для логирования
     */
    CrossoverResult crossover(String parent1, String parent2, double pc, Random random);
}
