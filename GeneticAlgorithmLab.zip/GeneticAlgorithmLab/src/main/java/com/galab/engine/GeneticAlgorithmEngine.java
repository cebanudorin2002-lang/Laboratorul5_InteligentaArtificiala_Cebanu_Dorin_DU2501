package com.galab.engine;

import com.galab.model.ExperimentResult;
import com.galab.model.GenerationStats;
import com.galab.model.Individual;
import com.galab.util.GaConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Движок генетического алгоритма.
 * Использует операторы селекции, кроссовера и мутации через интерфейсы.
 */
public final class GeneticAlgorithmEngine {

    private final int n;
    private final double pc;
    private final double pm;
    private final int g;
    private final Random random;

    private final SelectionOperator selectionOperator;
    private final CrossoverOperator crossoverOperator;
    private final MutationOperator mutationOperator;

    public GeneticAlgorithmEngine(int n, double pc, double pm, int g, Long seed) {
        this(n, pc, pm, g, seed,
                new RouletteWheelSelection(),
                new OnePointCrossover(),
                new BitFlipMutation());
    }

    public GeneticAlgorithmEngine(int n,
                                  double pc,
                                  double pm,
                                  int g,
                                  Long seed,
                                  SelectionOperator selectionOperator,
                                  CrossoverOperator crossoverOperator,
                                  MutationOperator mutationOperator) {
        this.n = n;
        this.pc = pc;
        this.pm = pm;
        this.g = g;
        this.random = (seed != null) ? new Random(seed) : new Random();
        this.selectionOperator = selectionOperator;
        this.crossoverOperator = crossoverOperator;
        this.mutationOperator = mutationOperator;
    }

    public ExperimentResult run(String experimentName) {
        StringBuilder log = new StringBuilder();
        List<GenerationStats> history = new ArrayList<>();

        log.append("Пояснение этапа инициализации: формируется начальная популяция из N=")
                .append(n).append(" случайных 4-битных хромосом.\n\n");

        // Этап 1: Инициализация начальной популяции
        List<Individual> currentPop = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            currentPop.add(new Individual(randomBinaryString()));
        }

        Individual bestOverall = null;
        int firstGenFoundBest = 1;

        // Цикл по поколениям 1..G
        for (int gen = 1; gen <= g; gen++) {
            GenerationStats stats = new GenerationStats(gen, currentPop);
            history.add(stats);

            if (bestOverall == null || stats.getBestInGeneration().getFitness() > bestOverall.getFitness() + 1e-9) {
                bestOverall = stats.getBestInGeneration();
                firstGenFoundBest = gen;
            }

            // Запись структуры лога строго по Разделу 8
            log.append("Поколение: ").append(gen).append("\n\n");
            log.append("Популяция:\n");
            for (int i = 0; i < currentPop.size(); i++) {
                Individual ind = currentPop.get(i);
                log.append(String.format(Locale.US,
                        "%d. Хромосома: %s | Десятичное значение: %d | x: %.4f | fitness: %.4f\n",
                        i + 1, ind.getChromosome(), ind.getDecimalValue(), ind.getX(), ind.getFitness()));
            }
            log.append("\n");

            // Формирование нового поколения
            List<String> nextGenChromosomes = new ArrayList<>(n);
            List<String> selectionLog = new ArrayList<>();
            List<String> crossoverLog = new ArrayList<>();

            int pairIndex = 1;
            while (nextGenChromosomes.size() < n) {
                int p1Index = selectionOperator.select(currentPop, random);
                int p2Index = selectionOperator.select(currentPop, random);

                // Если популяция > 1, стараемся выбрать различных родителей
                if (n > 1 && p1Index == p2Index) {
                    p2Index = (p1Index + 1 + random.nextInt(n - 1)) % n;
                }

                Individual parent1 = currentPop.get(p1Index);
                Individual parent2 = currentPop.get(p2Index);

                selectionLog.add(String.format(
                        "- Пара %d: Родитель 1: особь №%d (%s) | Родитель 2: особь №%d (%s) [Пропорциональная селекция (рулетка)]",
                        pairIndex, p1Index + 1, parent1.getChromosome(), p2Index + 1, parent2.getChromosome()));

                CrossoverOperator.CrossoverResult crossResult =
                        crossoverOperator.crossover(parent1.getChromosome(), parent2.getChromosome(), pc, random);

                if (crossResult.performed) {
                    crossoverLog.add(String.format(
                            "- Пара %d -> Кроссовер выполнен: да (r=%.2f < pc=%.2f)\n  Точка кроссовера: %d\n  Потомки: %s и %s",
                            pairIndex, crossResult.randomValue, pc, crossResult.cutPoint,
                            crossResult.child1, crossResult.child2));
                } else {
                    crossoverLog.add(String.format(
                            "- Пара %d -> Кроссовер выполнен: нет (r=%.2f >= pc=%.2f), потомки копируют родителей: %s и %s",
                            pairIndex, crossResult.randomValue, pc, crossResult.child1, crossResult.child2));
                }

                nextGenChromosomes.add(crossResult.child1);
                if (nextGenChromosomes.size() < n) {
                    nextGenChromosomes.add(crossResult.child2);
                }
                pairIndex++;
            }

            // Вывод блока Селекция
            log.append("Селекция:\n");
            for (String s : selectionLog) {
                log.append(s).append("\n");
            }
            log.append("\n");

            // Вывод блока Кроссовер
            log.append("Кроссовер:\n");
            for (String c : crossoverLog) {
                log.append(c).append("\n");
            }
            log.append("\n");

            // Этап мутации
            log.append("Мутация:\n");
            boolean anyMutation = false;
            List<Individual> nextPop = new ArrayList<>(n);

            for (int i = 0; i < nextGenChromosomes.size(); i++) {
                MutationOperator.MutationResult mutResult =
                        mutationOperator.mutate(nextGenChromosomes.get(i), i + 1, pm, random);
                if (!mutResult.logDetails.isEmpty()) {
                    anyMutation = true;
                    log.append(mutResult.logDetails);
                }
                nextPop.add(new Individual(mutResult.mutatedChromosome));
            }

            if (!anyMutation) {
                log.append("- Мутаций в данном поколении не произошло (все случайные числа >= pm)\n");
            }
            log.append("\n");

            // Статистика поколения
            log.append("Статистика поколения:\n");
            log.append(String.format(Locale.US, "- Максимальный fitness: %.4f\n", stats.getMaxFitness()));
            log.append(String.format(Locale.US, "- Минимальный fitness: %.4f\n", stats.getMinFitness()));
            log.append(String.format(Locale.US, "- Средний fitness: %.4f\n", stats.getAvgFitness()));
            log.append("--------------------------------------------------------------------------------\n\n");

            currentPop = nextPop;
        }

        // Итоговое резюме
        log.append("ИТОГОВЫЕ РЕЗУЛЬТАТЫ (").append(experimentName).append("):\n");
        log.append("- Лучшая найденная хромосома: ").append(bestOverall.getChromosome())
                .append(" (десятичное b = ").append(bestOverall.getDecimalValue()).append(")\n");
        log.append(String.format(Locale.US, "- Итоговое значение переменной x* = %.4f\n", bestOverall.getX()));
        log.append(String.format(Locale.US, "- Максимальное значение целевой функции f(x*) = %.4f\n", bestOverall.getFitness()));
        log.append("- Впервые найдено на поколении: ").append(firstGenFoundBest).append("\n");

        return new ExperimentResult(
                experimentName, n, pc, pm, g,
                history, bestOverall, firstGenFoundBest, log.toString()
        );
    }

    private String randomBinaryString() {
        StringBuilder sb = new StringBuilder(GaConstants.CHROMOSOME_LENGTH);
        for (int i = 0; i < GaConstants.CHROMOSOME_LENGTH; i++) {
            sb.append(random.nextBoolean() ? '1' : '0');
        }
        return sb.toString();
    }
}
