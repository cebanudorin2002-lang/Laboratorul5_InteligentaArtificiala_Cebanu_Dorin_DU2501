package com.galab.engine;

import com.galab.util.GaConstants;

import java.util.Random;

/**
 * Одноточечный кроссовер.
 * Точка разреза выбирается равномерно из диапазона [1, L-1].
 */
public final class OnePointCrossover implements CrossoverOperator {

    @Override
    public CrossoverResult crossover(String parent1, String parent2, double pc, Random random) {
        double r = random.nextDouble();
        if (r < pc) {
            int cutPoint = 1 + random.nextInt(GaConstants.CHROMOSOME_LENGTH - 1);
            String child1 = parent1.substring(0, cutPoint) + parent2.substring(cutPoint);
            String child2 = parent2.substring(0, cutPoint) + parent1.substring(cutPoint);
            return new CrossoverResult(child1, child2, true, cutPoint, r);
        } else {
            return new CrossoverResult(parent1, parent2, false, -1, r);
        }
    }
}
