package com.galab.engine;

import com.galab.util.GaConstants;

import java.util.Random;

/**
 * Побитовая мутация: каждый бит инвертируется с вероятностью pm.
 */
public final class BitFlipMutation implements MutationOperator {

    @Override
    public MutationResult mutate(String chromosome, int individualIndex, double pm, Random random) {
        char[] bits = chromosome.toCharArray();
        StringBuilder log = new StringBuilder();

        for (int bitIdx = 0; bitIdx < GaConstants.CHROMOSOME_LENGTH; bitIdx++) {
            if (random.nextDouble() < pm) {
                char oldBit = bits[bitIdx];
                char newBit = (oldBit == '0') ? '1' : '0';
                bits[bitIdx] = newBit;
                log.append(String.format(
                        "- Мутация в особи №%d, бит %d изменен с %c на %c\n",
                        individualIndex, bitIdx + 1, oldBit, newBit));
            }
        }

        return new MutationResult(new String(bits), log.toString());
    }
}
