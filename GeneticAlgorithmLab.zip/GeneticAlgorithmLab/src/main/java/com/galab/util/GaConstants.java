package com.galab.util;

/**
 * Константы лабораторной работы по генетическому алгоритму.
 */
public final class GaConstants {

    private GaConstants() {
        // utility class
    }

    /** Фиксированная длина хромосомы по условию задания. */
    public static final int CHROMOSOME_LENGTH = 4;

    /** Максимальное десятичное значение: 2^L - 1 = 15. */
    public static final int MAX_DECIMAL_VALUE = (1 << CHROMOSOME_LENGTH) - 1;
}
